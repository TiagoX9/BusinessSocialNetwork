module.exports = {
  mongoURI: "mongodb://tiago:tiago@ds019986.mlab.com:19986/devconnector",
  secretOrKey: "secret"
};
